
#include <gtk/gtk.h>
#include <cairo.h>
#include <math.h>

#define WIDTH  800
#define HEIGHT 600

static double a = 1.0; // Paramètre a de la fonction logarithmique
static double C = 0.0; // Constante C de la fonction logarithmique

static double fonction_logarithmique(double x) {
    return log(a * x) + C; // Fonction logarithmique avec paramètres a et C
}

static gboolean on_draw_event(GtkWidget *widget, cairo_t *cr, gpointer user_data) {
    gint width, height;
    gtk_widget_get_size_request(widget, &width, &height);

    // Effacer le contexte avec une couleur de fond blanche
    cairo_set_source_rgb(cr, 1, 1, 1);
    cairo_paint(cr);

    // Dessiner les axes
    cairo_set_source_rgb(cr, 0, 0, 0);
    cairo_set_line_width(cr, 1.0);
    cairo_move_to(cr, 50, 50); // Origine de l'axe des abscisses
    cairo_line_to(cr, width - 50, 50); // Dessiner l'axe des abscisses
    cairo_move_to(cr, 50, 50); // Origine de l'axe des ordonnées
    cairo_line_to(cr, 50, height - 50); // Dessiner l'axe des ordonnées
    cairo_stroke(cr);

    // Dessiner les graduations sur l'axe horizontal
    cairo_set_font_size(cr, 10);
    cairo_set_source_rgb(cr, 0, 0, 0);
    for (int i = 0; i <= 10; i++) {
        double x = 50 + (double)i * (width - 100) / 10;
        cairo_move_to(cr, x, 50);
        cairo_line_to(cr, x, 45);
        cairo_stroke(cr);

        char text[16];
        snprintf(text, sizeof(text), "%d", i);
        cairo_text_extents_t extents;
        cairo_text_extents(cr, text, &extents);
        cairo_move_to(cr, x - extents.width / 2, 70);
        cairo_show_text(cr, text);
    }

    // Dessiner les graduations sur l'axe vertical
    for (int i = 0; i <= 10; i++) {
        double y = 50 + (double)i * (height - 100) / 10;
        cairo_move_to(cr, 50, y);
        cairo_line_to(cr, 45, y);
        cairo_stroke(cr);

        char text[16];
        snprintf(text, sizeof(text), "%d", i);
        cairo_text_extents_t extents;
        cairo_text_extents(cr, text, &extents);
        cairo_move_to(cr, 25 - extents.width / 2, y + extents.height / 2);
        cairo_show_text(cr, text);
    }

    // Dessiner la courbe de la fonction logarithmique
    cairo_set_source_rgb(cr, 0, 0, 1);
    cairo_set_line_width(cr, 2.0);
    cairo_move_to(cr, 50, height / 2); // Position de départ
    for (double x = 1.0; x <= width - 50; x += 1.0) {
        double y = fonction_logarithmique(x) * 100.0 + height / 2; // Échelle et translation pour mieux visualiser
        cairo_line_to(cr, x + 50, y);
    }
    cairo_stroke(cr); // Afficher la courbe tracée

    return FALSE;
}


static void on_slider_a_change(GtkAdjustment *adjustment, gpointer user_data) {
    a = gtk_adjustment_get_value(adjustment);
    GtkWidget *drawing_area = GTK_WIDGET(user_data);
    gtk_widget_queue_draw(drawing_area);
}

static void on_slider_C_change(GtkAdjustment *adjustment, gpointer user_data) {
    C = gtk_adjustment_get_value(adjustment);
    GtkWidget *drawing_area = GTK_WIDGET(user_data);
    gtk_widget_queue_draw(drawing_area);
}

int main(int argc, char *argv[]) {
    GtkWidget *window;
    GtkWidget *drawing_area;
    GtkAdjustment *adjustment_a;
    GtkAdjustment *adjustment_C;
    GtkWidget *slider_a;
    GtkWidget *slider_C;
    GtkWidget *label_fonction;

    gtk_init(&argc, &argv);

    // Créer une fenêtre GTK
    window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Fonction logarithmique");
    gtk_window_set_default_size(GTK_WINDOW(window), WIDTH, HEIGHT);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    // Créer une zone de dessin GTK
    drawing_area = gtk_drawing_area_new();
    gtk_widget_set_size_request(drawing_area, WIDTH, HEIGHT);
    g_signal_connect(drawing_area, "draw", G_CALLBACK(on_draw_event), NULL);

    // Créer un réglage pour le paramètre a
    adjustment_a = gtk_adjustment_new(1.0, 0.1, 10.0, 0.1, 1.0, 0.0);
    g_signal_connect(adjustment_a, "value-changed", G_CALLBACK(on_slider_a_change), drawing_area);

    // Créer une barre de défilement (slider) pour le paramètre a
    slider_a = gtk_scale_new(GTK_ORIENTATION_HORIZONTAL, adjustment_a);
    gtk_widget_set_size_request(slider_a, WIDTH, -1);

    // Étiquette pour le paramètre a
    GtkWidget *label_a = gtk_label_new("Paramètre a:");
    gtk_widget_set_halign(label_a, GTK_ALIGN_START);

    // Créer un réglage pour la constante C
    adjustment_C = gtk_adjustment_new(0.0, -10.0, 10.0, 0.1, 1.0, 0.0);
    g_signal_connect(adjustment_C, "value-changed", G_CALLBACK(on_slider_C_change), drawing_area);

    // Créer une barre de défilement (slider) pour la constante C
    slider_C = gtk_scale_new(GTK_ORIENTATION_HORIZONTAL, adjustment_C);
    gtk_widget_set_size_request(slider_C, WIDTH, -1);

    // Étiquette pour la constante C
    GtkWidget *label_C = gtk_label_new("Constante C:");
    gtk_widget_set_halign(label_C, GTK_ALIGN_START);

    // Étiquette pour afficher la fonction
    label_fonction = gtk_label_new(NULL);
    gtk_label_set_markup(GTK_LABEL(label_fonction), "<b>Fonction:</b> log(a * x) + C");
    gtk_widget_set_halign(label_fonction, GTK_ALIGN_CENTER);

    // Créer une boîte de disposition pour organiser les widgets
    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), vbox);
    gtk_box_pack_start(GTK_BOX(vbox), label_a, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), slider_a, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), label_C, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), slider_C, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), label_fonction, FALSE, FALSE, 0);
    gtk_box_pack_start(GTK_BOX(vbox), drawing_area, TRUE, TRUE, 0);

    // Afficher la fenêtre
    gtk_widget_show_all(window);

    // Lancer la boucle principale GTK
    gtk_main();

    return 0;
}


