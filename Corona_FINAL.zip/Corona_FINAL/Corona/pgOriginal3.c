#include <stdio.h>
#include <gtk/gtk.h>

GtkWidget *entry_num1;
GtkWidget *entry_num2;
GtkWidget *entry_result;

void on_operation_clicked(GtkWidget *button, gpointer operation) {
    double num1 = atof(gtk_entry_get_text(GTK_ENTRY(entry_num1)));
    double num2 = atof(gtk_entry_get_text(GTK_ENTRY(entry_num2)));
    double result;

    if (operation == "+") {
        result = num1 + num2;
    } else if (operation == "-") {
        result = num1 - num2;
    } else if (operation == "*") {
        result = num1 * num2;
    } else if (operation == "/") {
        if (num2 != 0) {
            result = num1 / num2;
        } else {
            gtk_entry_set_text(GTK_ENTRY(entry_result), "Error: Division by zero");
            return;
        }
    }

    char buffer[50];
    snprintf(buffer, sizeof(buffer), "%.2f", result);
    gtk_entry_set_text(GTK_ENTRY(entry_result), buffer);
}

int main(int argc, char *argv[]) {
    gtk_init(&argc, &argv);

    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    entry_num1 = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(vbox), entry_num1, FALSE, FALSE, 0);

    entry_num2 = gtk_entry_new();
    gtk_box_pack_start(GTK_BOX(vbox), entry_num2, FALSE, FALSE, 0);

    GtkWidget *hbox_buttons = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_box_pack_start(GTK_BOX(vbox), hbox_buttons, FALSE, FALSE, 0);

    GtkWidget *button_plus = gtk_button_new_with_label("+");
    g_signal_connect(button_plus, "clicked", G_CALLBACK(on_operation_clicked), "+");
    gtk_box_pack_start(GTK_BOX(hbox_buttons), button_plus, TRUE, TRUE, 0);

    GtkWidget *button_minus = gtk_button_new_with_label("-");
    g_signal_connect(button_minus, "clicked", G_CALLBACK(on_operation_clicked), "-");
    gtk_box_pack_start(GTK_BOX(hbox_buttons), button_minus, TRUE, TRUE, 0);

    GtkWidget *button_multiply = gtk_button_new_with_label("*");
    g_signal_connect(button_multiply, "clicked", G_CALLBACK(on_operation_clicked), "*");
    gtk_box_pack_start(GTK_BOX(hbox_buttons), button_multiply, TRUE, TRUE, 0);

    GtkWidget *button_divide = gtk_button_new_with_label("/");
    g_signal_connect(button_divide, "clicked", G_CALLBACK(on_operation_clicked), "/");
    gtk_box_pack_start(GTK_BOX(hbox_buttons), button_divide, TRUE, TRUE, 0);

    entry_result = gtk_entry_new();
    gtk_editable_set_editable(GTK_EDITABLE(entry_result), FALSE);
    gtk_box_pack_start(GTK_BOX(vbox), entry_result, FALSE, FALSE, 0);

    gtk_widget_show_all(window);

    gtk_main();

    return 0;
}

