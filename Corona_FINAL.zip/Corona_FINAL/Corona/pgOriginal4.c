#include <stdio.h>
#include <gtk/gtk.h>
#include <math.h>

GtkWidget *drawing_area;
GtkWidget *spin_button_a;
GtkWidget *spin_button_b;
GtkWidget *spin_button_c;
double racine1 = 0, racine2 = 0;
gboolean has_solutions = FALSE;

gboolean draw_callback(GtkWidget *widget, cairo_t *cr, gpointer data) {
    int width, height;
    gtk_widget_get_size_request(widget, &width, &height);

    // Effacer le dessin précédent
    cairo_set_source_rgb(cr, 1, 1, 1); // blanc
    cairo_paint(cr);

    // Dessiner les axes x et y
    cairo_set_source_rgb(cr, 0, 0, 0); // noir
    cairo_set_line_width(cr, 1);

    // Axe x
    cairo_move_to(cr, 0, height / 2);
    cairo_line_to(cr, width, height / 2);
    cairo_stroke(cr);

    // Axe y
    cairo_move_to(cr, width / 2, 0);
    cairo_line_to(cr, width / 2, height);
    cairo_stroke(cr);

    // Numéroter l'axe des x
    cairo_set_font_size(cr, 10);
    for (int i = -8; i <= 8; i++) {
        int x = (i + 8) * width / 16;
        cairo_move_to(cr, x, height / 2 + 5);
        cairo_line_to(cr, x, height / 2 - 5);
        cairo_stroke(cr);

        cairo_move_to(cr, x - 5, height / 2 + 20);
        cairo_show_text(cr, g_strdup_printf("%d", i));
    }

    // Numéroter l'axe des y
    for (int i = 1; i <= 15; i++) {
        int y = i * height / 15;
        cairo_move_to(cr, width / 2 - 5, y);
        cairo_line_to(cr, width / 2 + 5, y);
        cairo_stroke(cr);

        cairo_move_to(cr, width / 2 + 10, y + 5);
        cairo_show_text(cr, g_strdup_printf("%d", 8 - i));
    }

    // Dessiner la courbe des racines si des solutions existent
    if (has_solutions) {
        double x, y;
        cairo_set_source_rgb(cr, 1, 0, 0); // rouge
        cairo_set_line_width(cr, 2);

        x = racine1 * width / 16 + width / 2; // Mettre à l'échelle
        y = height / 2;
        cairo_move_to(cr, x, y);
        cairo_arc(cr, x, y, 3, 0, 2 * M_PI); // Dessiner un cercle centré sur la racine 1
        cairo_fill(cr);

        x = racine2 * width / 16 + width / 2; // Mettre à l'échelle
        y = height / 2;
        cairo_move_to(cr, x, y);
        cairo_arc(cr, x, y, 3, 0, 2 * M_PI); // Dessiner un cercle centré sur la racine 2
        cairo_fill(cr);
    }

    return FALSE;
}

void show_error_dialog(GtkWidget *window, const gchar *message) {
    GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(window),
                                               GTK_DIALOG_MODAL,
                                               GTK_MESSAGE_ERROR,
                                               GTK_BUTTONS_OK,
                                               "%s",
                                               message);
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}

void calculate_button_clicked(GtkWidget *widget, gpointer data) {
    // Calculer les valeurs de a, b et c
    double a = gtk_spin_button_get_value(GTK_SPIN_BUTTON(spin_button_a));
    double b = gtk_spin_button_get_value(GTK_SPIN_BUTTON(spin_button_b));
    double c = gtk_spin_button_get_value(GTK_SPIN_BUTTON(spin_button_c));

    // Calculer les racines de l'équation
    double discriminant = b * b - 4 * a * c;
    if (discriminant >= 0) {
        racine1 = (-b + sqrt(discriminant)) / (2 * a);
        racine2 = (-b - sqrt(discriminant)) / (2 * a);
        has_solutions = TRUE;
    } else {
        has_solutions = FALSE;
        show_error_dialog(GTK_WIDGET(gtk_widget_get_toplevel(GTK_WIDGET(widget))),
                          "Cette équation n'a pas de solutions réelles.");
    }

    gtk_widget_queue_draw(drawing_area);
}

int main(int argc, char *argv[]) {
    gtk_init(&argc, &argv);

    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    drawing_area = gtk_drawing_area_new();
    gtk_widget_set_size_request(drawing_area, 500, 300);
    g_signal_connect(G_OBJECT(drawing_area), "draw", G_CALLBACK(draw_callback), NULL);
    gtk_box_pack_start(GTK_BOX(vbox), drawing_area, TRUE, TRUE, 0);

    GtkWidget *hbox = gtk_box_new(GTK_ORIENTATION_HORIZONTAL, 5);
    gtk_box_pack_start(GTK_BOX(vbox), hbox, FALSE, FALSE, 0);

    // Spin buttons pour les coefficients a, b et c
    spin_button_a = gtk_spin_button_new_with_range(-100, 100, 0.1); // Plage plus large pour a
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_button_a), 1.0);
    gtk_box_pack_start(GTK_BOX(hbox), spin_button_a, FALSE, FALSE, 0);

    spin_button_b = gtk_spin_button_new_with_range(-100, 100, 0.1); // Plage plus large pour b
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_button_b), 0.0);
    gtk_box_pack_start(GTK_BOX(hbox), spin_button_b, FALSE, FALSE, 0);

    spin_button_c = gtk_spin_button_new_with_range(-100, 100, 0.1); // Plage plus large pour c
    gtk_spin_button_set_value(GTK_SPIN_BUTTON(spin_button_c), 0.0);
    gtk_box_pack_start(GTK_BOX(hbox), spin_button_c, FALSE, FALSE, 0);

    GtkWidget *calculate_button = gtk_button_new_with_label("Valider");
    g_signal_connect(G_OBJECT(calculate_button), "clicked", G_CALLBACK(calculate_button_clicked), NULL);
    gtk_box_pack_start(GTK_BOX(hbox), calculate_button, FALSE, FALSE, 0);

    gtk_widget_show_all(window);

    gtk_main();

    return 0;
}

