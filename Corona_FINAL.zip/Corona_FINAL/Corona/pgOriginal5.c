#include <stdio.h>
#include <gtk/gtk.h>

// Fonction pour calculer le PGCD de deux nombres
int pgcd(int a, int b) {
    int temp;

    while (b != 0) {
        temp = b;
        b = a % b;
        a = temp;
    }

    return a;
}

// Fonction pour calculer le PPCM de deux nombres
int ppcm(int a, int b) {
    int pg = pgcd(a, b);
    return (a * b) / pg;
}

// Callback appelée lorsque le bouton de calcul est cliqué
void calculate_button_clicked(GtkWidget *widget, gpointer data) {
    // Récupérer les valeurs entrées par l'utilisateur
    GtkWidget *entry1 = GTK_WIDGET(data);
    GtkWidget *entry2 = g_object_get_data(G_OBJECT(entry1), "entry2");
    int nombre1 = atoi(gtk_entry_get_text(GTK_ENTRY(entry1)));
    int nombre2 = atoi(gtk_entry_get_text(GTK_ENTRY(entry2)));

    // Calculer le PPCM
    int resultat = ppcm(nombre1, nombre2);

    // Afficher le résultat dans une boîte de dialogue
    GtkWidget *dialog = gtk_message_dialog_new(GTK_WINDOW(gtk_widget_get_toplevel(widget)),
                                               GTK_DIALOG_MODAL,
                                               GTK_MESSAGE_INFO,
                                               GTK_BUTTONS_OK,
                                               "Le PPCM de %d et %d est : %d",
                                               nombre1, nombre2, resultat);
    gtk_dialog_run(GTK_DIALOG(dialog));
    gtk_widget_destroy(dialog);
}

int main(int argc, char *argv[]) {
    // Initialiser GTK
    gtk_init(&argc, &argv);

    // Créer la fenêtre principale
    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_title(GTK_WINDOW(window), "Calcul du PPCM");
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    // Créer une boîte verticale pour les widgets
    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 10);
    gtk_container_set_border_width(GTK_CONTAINER(vbox), 10);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    // Créer deux champs de texte pour les nombres
    GtkWidget *entry1 = gtk_entry_new();
    GtkWidget *entry2 = gtk_entry_new();
    gtk_container_add(GTK_CONTAINER(vbox), entry1);
    gtk_container_add(GTK_CONTAINER(vbox), entry2);
    g_object_set_data(G_OBJECT(entry1), "entry2", entry2);

    // Créer un bouton de calcul
    GtkWidget *calculate_button = gtk_button_new_with_label("Calculer");
    g_signal_connect(G_OBJECT(calculate_button), "clicked", G_CALLBACK(calculate_button_clicked), entry1);
    gtk_container_add(GTK_CONTAINER(vbox), calculate_button);

    // Afficher tous les widgets
    gtk_widget_show_all(window);

    // Démarrer la boucle principale GTK
    gtk_main();

    return 0;
}

