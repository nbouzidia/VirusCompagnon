#include <gtk/gtk.h>
#include <math.h>

#define WIDTH   600
#define HEIGHT  400

double amplitude = 1.0;
double frequency = 1.0;
double phase = 0.0;

gboolean on_draw(GtkWidget *widget, cairo_t *cr, gpointer data) {
    int width, height;
    gtk_widget_get_size_request(widget, &width, &height);

    // Effacer le dessin précédent
    cairo_set_source_rgb(cr, 1, 1, 1); // Blanc
    cairo_paint(cr);

    // Dessiner les axes x et y
    cairo_set_source_rgb(cr, 0, 0, 0); // Noir
    cairo_set_line_width(cr, 1);

    // Dessiner l'axe des x
    cairo_move_to(cr, 0, height / 2);
    cairo_line_to(cr, width, height / 2);
    cairo_stroke(cr);

    // Dessiner l'axe des y
    cairo_move_to(cr, width / 2, 0);
    cairo_line_to(cr, width / 2, height);
    cairo_stroke(cr);

    // Numéroter l'axe des x
    cairo_select_font_face(cr, "Sans", CAIRO_FONT_SLANT_NORMAL, CAIRO_FONT_WEIGHT_NORMAL);
    cairo_set_font_size(cr, 10);

    for (int i = -10; i <= 10; ++i) {
        double x = width / 2 + i * (width / 20);
        double y = height / 2;
        cairo_move_to(cr, x, y + 5);
        cairo_show_text(cr, g_strdup_printf("%d", i));
    }

    // Numéroter l'axe des y
    for (int i = -10; i <= 10; ++i) {
        double x = width / 2;
        double y = height / 2 + i * (height / 20);
        cairo_move_to(cr, x - 15, y);
        cairo_show_text(cr, g_strdup_printf("%d", i));
    }

    // Dessiner la courbe sinus
    cairo_set_source_rgb(cr, 1, 0, 0); // Rouge
    cairo_set_line_width(cr, 2);
    cairo_move_to(cr, 0, height / 2 - amplitude * sin(phase));
    for (int i = 1; i <= width; ++i) {
        double x = i;
        double y = height / 2 - amplitude * sin(frequency * x / width * 2 * M_PI + phase);
        cairo_line_to(cr, x, y);
    }
    cairo_stroke(cr);

    return FALSE;
}

void show_dialog(GtkWidget *widget, gpointer data) {
    GtkWidget *dialog;
    GtkWidget *content_area;
    GtkWidget *label;
    GtkWidget *entry;
    gint result;

    dialog = gtk_dialog_new_with_buttons("Entrez la valeur de sin(x)",
                                         GTK_WINDOW(data),
                                         GTK_DIALOG_MODAL | GTK_DIALOG_DESTROY_WITH_PARENT,
                                         "Valider",
                                         GTK_RESPONSE_ACCEPT,
                                         "Annuler",
                                         GTK_RESPONSE_CANCEL,
                                         NULL);

    content_area = gtk_dialog_get_content_area(GTK_DIALOG(dialog));
    label = gtk_label_new("Valeur de sin(x) :");
    gtk_container_add(GTK_CONTAINER(content_area), label);

    entry = gtk_entry_new();
    gtk_container_add(GTK_CONTAINER(content_area), entry);

    gtk_widget_show_all(dialog);
    result = gtk_dialog_run(GTK_DIALOG(dialog));

    if (result == GTK_RESPONSE_ACCEPT) {
        const gchar *text = gtk_entry_get_text(GTK_ENTRY(entry));
        amplitude = atof(text);
        gtk_widget_queue_draw(GTK_WIDGET(data));
    }

    gtk_widget_destroy(dialog);
}

int main(int argc, char *argv[]) {
    gtk_init(&argc, &argv);

    GtkWidget *window = gtk_window_new(GTK_WINDOW_TOPLEVEL);
    gtk_window_set_default_size(GTK_WINDOW(window), WIDTH, HEIGHT);
    g_signal_connect(window, "destroy", G_CALLBACK(gtk_main_quit), NULL);

    GtkWidget *drawing_area = gtk_drawing_area_new();
    gtk_widget_set_size_request(drawing_area, WIDTH, HEIGHT);
    g_signal_connect(G_OBJECT(drawing_area), "draw", G_CALLBACK(on_draw), NULL);

    GtkWidget *vbox = gtk_box_new(GTK_ORIENTATION_VERTICAL, 5);
    gtk_box_pack_start(GTK_BOX(vbox), drawing_area, TRUE, TRUE, 0);
    gtk_container_add(GTK_CONTAINER(window), vbox);

    GtkWidget *button = gtk_button_new_with_label("Entrez une valeur de x");
    g_signal_connect(button, "clicked", G_CALLBACK(show_dialog), drawing_area);

    gtk_container_add(GTK_CONTAINER(vbox), button);

    gtk_widget_show_all(window);
    gtk_main();

    return 0;
}

